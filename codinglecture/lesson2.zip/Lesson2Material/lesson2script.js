function part1() {
    /* Write a hello world program below using the console */
}

function part2() {
    /* Write a program that asks for your name and then prints it out using the console */
}

function part3() {
    /* Write a program that asks for your name and then prints it out with extra text using the console */
}

function part4() {
    /* Ask the user for their name, store it in a variable, and print it out using the console */
}

function part5() {
    /* Ask the user for 2 numbers, add them together, and print the sum with an alert */
}

function part6() {
    /* Do the same as part 5 but use backticks */
}

function part7() {
    /* Convert human years to dog years */
}

function part8() {
    /* Convert fahrenheit to celsius */
}

function part9() {
    /* Use an if statement to determine if 2 inputs are equal and print the result */
}

function part10() {
    /* Ask the user for a number and determine if it is even */
}